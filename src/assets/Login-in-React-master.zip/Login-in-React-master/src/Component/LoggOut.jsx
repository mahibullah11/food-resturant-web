

function LoggOut({onlogin}) {
  return (
   <>
   <h2>Welcome, you are login</h2>
   
   <button onClick={onlogin}>logOut</button>
   </>
  )
}

export default LoggOut
