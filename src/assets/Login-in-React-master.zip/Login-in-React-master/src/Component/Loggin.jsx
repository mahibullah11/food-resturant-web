

function Loggin({onlogout}) {
  return (
    <div>
      <h2>Please Log In</h2>
      <button onClick={onlogout}>Login</button>
    </div>
  )
}

export default Loggin
